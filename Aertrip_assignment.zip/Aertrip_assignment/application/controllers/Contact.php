<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->load->model('api_model');
		$this->load->model('contact_model');
		$this->load->library('form_validation');
	}

	

	function insert()
	{
		$this->form_validation->set_rules('phone', 'Phone', 'required');
		
		if($this->form_validation->run())
		{
			$data = array(
				'phone'	=>	$this->input->post('phone'),
				'employee_id'	=>	$this->input->post('employee_id'),
				
			);

			$this->contact_model->insert_api($data);

			$array = array(
				'success'		=>	true
			);
		}
		else
		{
			$array = array(
				'error'					=>	true,
				'phone_error'		=>	form_error('phone'),
				
			);
		}
		echo json_encode($array);
	}
	
	
}


?>