<?php
class Address_model extends CI_Model
{
	function fetch_all()
	{
		$this->db->order_by('id', 'DESC');
		return $this->db->get('employee_address');
	}
	function insert_api($data)
	{
		$this->db->insert('employee_address', $data);
	}

	
}

?>