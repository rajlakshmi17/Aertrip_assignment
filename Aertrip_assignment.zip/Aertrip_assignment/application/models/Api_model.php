<?php
class Api_model extends CI_Model
{
	function fetch_all()
	{
		//$this->db->order_by('id', 'DESC');
		//return $this->db->get('employees');
		$this->db->select('employees.first_name,employees.last_name,department.name as dept_name,employees.id');
		$this->db->from('employees');
		$this->db->join('department', 'department.id = employees.department_id');
		return $query = $this->db->get();
	}

	function insert_api($data)
	{
		$this->db->insert('employees', $data);
	}

	function fetch_single_user($user_id)
	{
		$this->db->where('id', $user_id);
		$query = $this->db->get('employees');
		return $query->result_array();
	}
	function fetch_single_user_by_name($name)
	{
		$this->db->like('first_name',$name);
        $query  = $this->db->get('employees');
        return $query->result_array();
		//$this->db->where('first_name', $name);
		//$query = $this->db->get('employees');
		//return $query->result_array();
	}

	function update_api($user_id, $data)
	{
		$this->db->where('id', $user_id);
		$this->db->update('employees', $data);
	}

	function delete_single_user($user_id)
	{
		$this->db->where('id', $user_id);
		$this->db->delete('employees');
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}

?>