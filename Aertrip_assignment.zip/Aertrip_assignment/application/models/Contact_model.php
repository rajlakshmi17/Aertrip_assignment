<?php
class Contact_model extends CI_Model
{
	function fetch_all()
	{
		$this->db->order_by('id', 'DESC');
		return $this->db->get('employee_contact_details');
	}
	function insert_api($data)
	{
		$this->db->insert('employee_contact_details', $data);
	}

	
}

?>