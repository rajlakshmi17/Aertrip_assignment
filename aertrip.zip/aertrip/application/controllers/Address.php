<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Address extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->load->model('api_model');
		$this->load->model('address_model');
		$this->load->library('form_validation');
	}

	

	function insert()
	{
		$this->form_validation->set_rules('address', 'Address', 'required');
		
		if($this->form_validation->run())
		{
			$data = array(
				'address'	=>	$this->input->post('address'),
				'employee_id'	=>	$this->input->post('emp_id'),
				
			);

			$this->address_model->insert_api($data);

			$array = array(
				'success'		=>	true
			);
		}
		else
		{
			$array = array(
				'error'		=>	true,
				'address_error'		=>	form_error('address'),
				
			);
		}
		echo json_encode($array);
	}

	function fetch_employee_address()
	{
		if($this->input->post('employee_id')!='')
		{
			$ph_data = $this->address_model->fetch_employee_address($this->input->post('employee_id'));
            $data = $ph_data->result_array();
			echo json_encode($data);
		}
		
	}
	
	
}


?>