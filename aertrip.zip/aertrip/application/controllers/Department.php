<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Department extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->load->model('api_model');
		$this->load->model('department_model');
		$this->load->library('form_validation');
	}

	

	function insert_dept()
	{
		$this->form_validation->set_rules('name', 'Name', 'required');
		
		if($this->form_validation->run())
		{
			$data = array(
				'name'	=>	$this->input->post('name'),
				
			);

			$this->department_model->insert_api($data);

			$array = array(
				'success'		=>	true
			);
		}
		else
		{
			$array = array(
				'error'					=>	true,
				'name_error'		=>	form_error('name'),
				
			);
		}
		echo json_encode($array);
	}
	
	
}


?>