<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_api extends CI_Controller {

	function index()
	{
		$this->load->view('api_view');
	}

	function action()
	{
		if($this->input->post('data_action'))
		{
			$data_action = $this->input->post('data_action');

			if($data_action == "Insert_dept")
			{
				$api_url = "http://localhost/aertrip/department/insert_dept";
			

				$form_data = array(
					'name'		=>	$this->input->post('name'),
					
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				echo $response;


			}

			if($data_action == "Delete")
			{
				$api_url = "http://localhost/aertrip/api/delete";

				$form_data = array(
					'id'		=>	$this->input->post('user_id')
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				echo $response;




			}

			if($data_action == "Edit")
			{
				$api_url = "http://localhost/aertrip/api/update";

				$form_data = array(
					'first_name'		=>	$this->input->post('first_name'),
					'last_name'			=>	$this->input->post('last_name'),
					'id'				=>	$this->input->post('user_id'),
					'department_id'			=>	$this->input->post('department_id')
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				echo $response;







			}

			if($data_action == "fetch_single")
			{
				$api_url = "http://localhost/aertrip/api/fetch_single";

				$form_data = array(
					'id'=>	$this->input->post('user_id')
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				echo $response;






			}

			if($data_action == "Insert")
			{
				$api_url = "http://localhost/aertrip/api/insert";
			

				$form_data = array(
					'first_name'		=>	$this->input->post('first_name'),
					'last_name'			=>	$this->input->post('last_name'),
					'department_id'			=>	$this->input->post('department_id')
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				echo $response;


			}





			if($data_action == "fetch_all")
			{

				$api_url = "http://localhost/aertrip/api";

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				$result = json_decode($response);
				//print_r($result->employee_data); die;
			
				$output = '';

				if(count($result->employee_data) > 0)
				{
					foreach($result->employee_data as $row)
					{
						$output .= '
						<tr>
							<td>'.$row->first_name.'</td>
							<td>'.$row->last_name.'</td>
							<td>'.$row->dept_name.'</td>
							<td><butto type="button" name="edit" class="btn btn-warning btn-xs edit" id="'.$row->id.'">Edit</button></td>
							<td><button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$row->id.'">Delete</button></td>
							<td>
							
							<button type="button" id="add_phone" class="btn btn-info btn-xs" onclick="add_phone('.$row->id.')">View Phone</button>
							<button type="button" id="add_add" class="btn btn-info btn-xs" onclick="add_add('.$row->id.');">View Address</button>
							
						</tr>

						';
					}
				}
				else
				{
					$output .= '
					<tr>
						<td colspan="4" align="center">No Data Found</td>
					</tr>
					';
				}

				echo $output;
			}
			if($data_action == "fetch_department")
			{

				$api_url = "http://localhost/aertrip/api";

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				$result = json_decode($response);
				//print_r($result->employees); die;
			
				$output = '';

				if(count($result->department_list) > 0)
				{
					$output .= '<select name="department_id" id="department_id" class="form-control">
						            <option value="">Select</option>';
					foreach($result->department_list as $row)
					{
						$output .= '
                      				<option value="'.$row->id.'">'.$row->name.'</option>
                                    
						';
					}
					$output .= '</select>';
				}
				else
				{
					$output .= '<select name="department_id" id="department_id" class="form-control">
						            <option value="">Select</option></select>';
				}

				echo $output;
			}

			if($data_action == "search_by_name")
			{
				
				$api_url = "http://localhost/aertrip/api/fetch_single";

				$form_data = array(
					'name'=>	$this->input->post('search_val')
				);


				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);
				

				$result =  json_decode($response);
				//print_r($row); die;
			
				$output = '';
				if($this->input->post('search_val')=='')
				{
					$output .= '
						<tr>
							<td colspan="4" align="center">No Data Found</td>
						</tr>
						';
				}
                else
                {
                	if(count($result) > 0)
				    {
						foreach($result as $row)
						{
							$output .= '
							<tr>
								<td>'.$row->first_name.'</td>
								<td>'.$row->last_name.'</td>
								<td>'.$row->dept_name.'</td>
								<td><butto type="button" name="edit" class="btn btn-warning btn-xs edit" id="'.$row->id.'">Edit</button></td>
								<td><button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$row->id.'">Delete</button></td>
								<td>
								
								<button type="button" id="add_phone" class="btn btn-info btn-xs" onclick="add_phone('.$row->id.')">View Phone</button>
								<button type="button" id="add_add" class="btn btn-info btn-xs" onclick="add_add('.$row->id.');">View Address</button>
								
							</tr>

							';
						}
					}
					else
					{
						$output .= '
						<tr>
							<td colspan="4" align="center">No Data Found</td>
						</tr>
						';
					}
                }
				    
                    
                   
				echo $output;

			}

			if($data_action == "Insert_phone")
			{
				$api_url = "http://localhost/aertrip/contact/insert";
			

				$form_data = array(
					'phone'=>	$this->input->post('phone'),
					'employee_id'=>	$this->input->post('employee_id'),
					
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				echo $response;


			}
			if($data_action == "Insert_add")
			{
				$api_url = "http://localhost/aertrip/address/insert";
			

				$form_data = array(
					'address'=>	$this->input->post('address'),
					'emp_id'=>	$this->input->post('emp_id'),
					
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				echo $response;


			}

			if($data_action == "fetch_employee_phone")
			{
				$api_url = "http://localhost/aertrip/contact/fetch_employee_phone";

				$form_data = array(
					'employee_id'=>	$this->input->post('employee_id')
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				//echo $response; die;
                $result = json_decode($response);
				//print_r($result->employees); die;
			
				$output = '<table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Serial Number</th>
                            <th>Phone Number</th>
                            
                        </tr>
                    </thead><tbody>';
                    
               
                
				if(count($result) > 0)
				{
					foreach ($result as $row) 
					{
						$output .= '
							<tr>
								<td>'.$row->id.'</td>
								<td>'.$row->phone.'</td>
								
							</tr>

							';	
					}
						
				}
				else
				{
					$output .= '
					<tr>
						<td colspan="4" align="center">No Data Found</td>
					</tr>
					';
				}
				
				$output .='</tbody></table>';
                echo $output;



			}

			if($data_action == "fetch_employee_address")
			{
				$api_url = "http://localhost/aertrip/address/fetch_employee_address";

				$form_data = array(
					'employee_id'=>	$this->input->post('employee_id')
				);

				$client = curl_init($api_url);

				curl_setopt($client, CURLOPT_POST, true);

				curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

				curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

				$response = curl_exec($client);

				curl_close($client);

				//echo $response; die;
                $result = json_decode($response);
				//print_r($result->employees); die;
			
				$output = '<table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Serial Number</th>
                            <th>Address</th>
                            
                        </tr>
                    </thead><tbody>';
                    
               
                
				if(count($result) > 0)
				{
					foreach ($result as $row) 
					{
						$output .= '
							<tr>
								<td>'.$row->id.'</td>
								<td>'.$row->address.'</td>
								
							</tr>

							';	
					}
						
				}
				else
				{
					$output .= '
					<tr>
						<td colspan="4" align="center">No Data Found</td>
					</tr>
					';
				}
				
				$output .='</tbody></table>';
                echo $output;



			}

		}
	}
	
}

?>