<?php
class Address_model extends CI_Model
{
	function fetch_all()
	{
		$this->db->order_by('id', 'DESC');
		return $this->db->get('employee_address');
	}
	function insert_api($data)
	{
		$this->db->insert('employee_address', $data);
	}
	function fetch_employee_address($data)
	{
		
		$this->db->select('id,employee_id,address');
		$this->db->from('employee_address');
		$this->db->where('employee_id',$data);
		return $query = $this->db->get();
		//return $query->result_array();
	}

	
}

?>