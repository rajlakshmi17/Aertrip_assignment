<?php
class Contact_model extends CI_Model
{
	function fetch_all()
	{
		$this->db->order_by('id', 'DESC');
		return $this->db->get('employee_contact_details');
	}
	function insert_api($data)
	{
		$this->db->insert('employee_contact_details', $data);
	}
	function fetch_employee_contact($data)
	{
		
		$this->db->select('id,employee_id,phone');
		$this->db->from('employee_contact_details');
		$this->db->where('employee_id',$data);
		return $query = $this->db->get();
		//return $query->result_array();
	}

	
}

?>